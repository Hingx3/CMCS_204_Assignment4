import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CourseDBManager_STUDENT_Test {
	
	private CourseDBManagerInterface test = new CourseDBManager();
	
	@BeforeEach
	void setUp() throws Exception {
		test = new CourseDBManager();
	}

	@AfterEach
	void tearDown() throws Exception {
		test = null;
	}

	@Test
	void testAdd() {
		try {
			test.add("CMSC204",22566,4,"Zoom","Professor Khandan Monshi");
		}
		catch(Exception e) {
			fail("This should not have caused an Exception");
		}
	}
	
	@Test
	void testShowAll() {
		test.add("CMSC204",22566,4,"Zoom","Professor Khandan Monshi");
		test.add("CMSC204",22566,4,"Zoom","Somebody else");
		ArrayList<String> list = test.showAll();
		
		assertEquals(list.get(0),"\nCourse:CMSC204 CRN:22566 Credits:4 Instructor:Professor Khandan Monshi Room:Zoom");
		assertEquals(list.get(1),"\nCourse:CMSC204 CRN:22566 Credits:4 Instructor:Somebody else Room:Zoom");
	}
	
	@Test
	void testReadFile() {
		try {
			File inputFile = new File("Test1.txt");
			PrintWriter inFile = new PrintWriter(inputFile);
			inFile.println("CMSC204 22566 4 Zoom Joey Professor Khandan Monshi");
			inFile.print("CMSC204 22566 4 Zoom Somebody else");
			inFile.close();
			test.readFile(inputFile);
		} catch (Exception e) {
			fail("Should not have thrown an exception");
		}
	}

}
