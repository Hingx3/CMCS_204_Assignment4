
public class CourseDBElement implements Comparable<CourseDBElement>{

	public String id;
	public int crn;
	public int credits;
	public String roomNum;
	public String instructor;
	String str = crn + "";
	
	public CourseDBElement() {
		
	}
	
	public CourseDBElement(String id, int crn, int credits, String roomNum, String instructor) {
		this.id = id;
		this.crn = crn;
		this.credits = credits;
		this.roomNum = roomNum;
		this.instructor = instructor;
	}
	
	public String getID() {
		return id;
	}
	
	public void setID(String courseID) {
		this.id = courseID;
		
	}
	
	public int getCRN() {
		return crn;
	}
	
	public void setCRN(int crn) {
		this.crn = crn;
		
	}
	
	public int getCredits() {
		return credits;
	}
	
	public void setCredits(int credits) {
		this.credits = credits;
		
	}
	
	public String getRoomNum() {
		return roomNum;
	}
	
	public void setRoomNum(String roomNum) {
		this.roomNum = roomNum;
		
	}
	
	public String getInstructor() {
		return instructor;
	}
	
	public void setInstructor(String instructor) {
		this.instructor = instructor;
		
	}
	
	public String toString() {		
		return "\nCourse:"+id+" CRN:"+crn+" Credits:"+credits+" Instructor:"+instructor+" Room:"+roomNum;
		
	}
	
	
	
	public int hashCode() {
		String str = crn + "";
		return str.hashCode();
	}
	

	

	@Override
	public int compareTo(CourseDBElement o) {		
		return str.compareTo(o.str);
	}

	
	
}
