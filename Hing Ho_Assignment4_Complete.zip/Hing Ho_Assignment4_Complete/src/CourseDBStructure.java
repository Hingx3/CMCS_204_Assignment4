import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface {
	
	public LinkedList<CourseDBElement>[] hashTable;	
	private static final int K = 1;
	private static final double LOAD_FACTOR = 1.5;
	
	
	public CourseDBStructure(int n) {
		int temp = (int)(n / LOAD_FACTOR);
		int size = temp + (4 * K + 3);		
		boolean b = false;
		
		do {			
			int x = 19;
			while (x < size / 2) {
				if (size / x != 0)			
					break;
				else	
					x++;		
			}

		if (x == size) {			
			b = true;
		}
			
		else {
			size += (4 * K + 3);
		}		
		} while (!b);
		
		
		hashTable = new LinkedList[size];
		
	}
	
	
	public CourseDBStructure(String testing, int size) {
		hashTable = new LinkedList[size];
	}
	
	/** 
	* Adds a CourseDBElement object to the CourseDBStructure using the hashcode
	* of the CourseDatabaseElemen object's crn value.
	* If the CourseDatabaseElement already exists, exit quietly
	*  
	* @param element the CourseDBElement to be added to CourseDBStructure
	*/
	@Override
	public void add(CourseDBElement element) {
		int x =element.hashCode()% hashTable.length;

		
		if (hashTable[x] == null) {		     
			hashTable[x] = new LinkedList<CourseDBElement>();		      	      
			hashTable[x].add(element);		   
		} 
		else {		      
			if (hashTable[x].contains(element))		       
				return;		     
			else		     
				hashTable[x].add(element);	
			
		}		
	}

	/**
	 * Find a courseDatabaseElement based on the key (crn) of the
	 * courseDatabaseElement If the CourseDatabaseElement is found return it If not,
	 * throw an IOException
	 * 
	 * @param crn crn (key) whose associated courseDatabaseElement is to be returned
	 * @return a CourseDBElement whose crn is mapped to the key
	 * @throws IOException if key is not found
	 */
	@Override
	public CourseDBElement get(int crn) throws IOException {		
		String str = crn + "";		
		int x = str.hashCode() % hashTable.length;
		
		if(hashTable[x] == null) {
			throw new IOException();
		}
		else {
			for(int i=0; i<hashTable.length; i++) {
				CourseDBElement temp = hashTable[x].get(i);
				if(temp.getCRN() == crn) {
					return temp;
				}
			}
			return null;
		}	
	}

	/**
	 * @return an array list of string representation of each course in 
	 * the data structure separated by a new line. 
	 * Refer to the following example:
	 * Course:CMSC500 CRN:39999 Credits:4 Instructor:Nobody InParticular Room:SC100
	 * Course:CMSC600 CRN:4000 Credits:4 Instructor:Somebody Room:SC200
	 */
	@Override
	public ArrayList<String> showAll() {
		ArrayList<String> courses=new ArrayList<String>();
		
		for(int i=0; i<hashTable.length; i++) {
			if(hashTable[i]!=null) {
				LinkedList<CourseDBElement> list = hashTable[i];
				for(int j=0;j<hashTable[i].size();j++) {
					CourseDBElement element= (CourseDBElement) hashTable[i].get(j);
					courses.add(element.toString());
					
				}
				
			}
		}
		
		return courses;
	}

	/**
	* Returns the size of the ConcordanceDataStructure (number of indexes in the array)
	*/
	@Override
	public int getTableSize() {
		return hashTable.length;
	}

	
	
}
